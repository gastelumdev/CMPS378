# Psuedocode
* Output a greeting
* Output the menu
* Ask user to input their food choice as a character
* Ask user to input their drink choice as a character
* Ask user if they would like desert
* If they do:
    + Ask user to input their desert choice as a character
* Ask user if they would like to add another order
* If they do:
    + Go back to output menu
* Else:
* Display their order and their total
* display a random fortune cookie quote
* Display goodbye
